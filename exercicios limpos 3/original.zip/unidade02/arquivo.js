// JavaScript Document
alert("ola mundo");